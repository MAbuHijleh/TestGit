﻿using FirstApi.Models;
using FirstApi.Tables;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FirstApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MajorsController : ControllerBase
    {
        private readonly ApplicationDBContext _context;

        public MajorsController(ApplicationDBContext context) {
            _context = context;
        }   

        [HttpGet]
        public async Task<IActionResult> GetMajors() {
            var list=await _context.Majors.OrderBy(c=>c.Name).ToListAsync();
            return Ok(list);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetMajorById(int id)
        {
            var obj = await _context.Majors.FirstOrDefaultAsync(c =>  c.Id == id);
            if(obj == null)
            {
                return NotFound("The Major is not Found");
            }

            return Ok(obj);
        }

        [HttpPost]
        public async Task<IActionResult> CreateMajor(MajorModel model)
        {
            var obj = new Major()
            {
                Name = model.Name,
                Description = model.Description
            };

            obj.Name=model.Name;
            obj.Description=model.Description;

            await _context.Majors.AddAsync(obj);
            await _context.SaveChangesAsync();

            return Ok();
        }

        [HttpPut]
        public async Task<IActionResult> updateMajor(int id,MajorModel model)
        {
            var obj = await _context.Majors.FirstOrDefaultAsync(c => c.Id == id);
            if (obj == null)
            {
                return NotFound("The Requested Model was not found");

            }
            obj.Description = model.Description;
            obj.Name = model.Name;
            await _context.SaveChangesAsync();


            return Ok();
        }

        [HttpDelete]
        public async Task<IActionResult> deleteMajor(int id, MajorModel model)
        {
            var obj = await _context.Majors.FirstOrDefaultAsync(c => c.Id == id);
            if (obj == null)
            {
                return NotFound("The Requested Model was not found");

            }
            _context.Majors.Remove(obj);
            await _context.SaveChangesAsync();  
            return Ok();
        }
    }
}
