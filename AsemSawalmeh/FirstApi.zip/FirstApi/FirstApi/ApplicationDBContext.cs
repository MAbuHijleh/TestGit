﻿using FirstApi.Tables;
using Microsoft.EntityFrameworkCore;

namespace FirstApi
{
    public class ApplicationDBContext:DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> option) : base(option){ 

        }  
        public DbSet<Major>Majors { get; set; }
    }
}
